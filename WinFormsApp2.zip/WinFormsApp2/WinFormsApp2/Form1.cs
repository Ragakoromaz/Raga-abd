using System.Linq;

namespace WinFormsApp2
{
    public partial class Form1 : Form
    {
        bool lastIsOperation = true;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            lastIsOperation = false;
            textBox1.Text = textBox1.Text + "1";
            evaluate();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            lastIsOperation = false;
            textBox1.Text = textBox1.Text + "2";
            evaluate();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            lastIsOperation = false;
            textBox1.Text = textBox1.Text + "3";
            evaluate();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            lastIsOperation = false;
            textBox1.Text = textBox1.Text + "4";
            evaluate();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            lastIsOperation = false;
            textBox1.Text = textBox1.Text + "5";
            evaluate();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            lastIsOperation = false;
            textBox1.Text = textBox1.Text + "6";
            evaluate();
        }


        private void button7_Click(object sender, EventArgs e)
        {
            lastIsOperation = false;
            textBox1.Text = textBox1.Text + "7";
            evaluate();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            lastIsOperation = false;
            textBox1.Text = textBox1.Text + "8";
            evaluate();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            lastIsOperation = false;
            textBox1.Text = textBox1.Text + "9";
            evaluate();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            lastIsOperation = false;
            textBox1.Text = textBox1.Text + "0";
            evaluate();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (!lastIsOperation)
            {
                lastIsOperation = true;
                textBox1.Text = textBox1.Text + "^";
                textBox2.Text = "";
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (!lastIsOperation)
            {
                lastIsOperation = true;
                textBox1.Text = textBox1.Text + "/";
                textBox2.Text = "";
            }
        }
        private void button15_Click(object sender, EventArgs e)
        {
            if (!lastIsOperation)
            {
                lastIsOperation = true;
                textBox1.Text = textBox1.Text + "*";
                textBox2.Text = "";
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (lastIsNumber())
            {
                textBox1.Text = textBox1.Text + ".";
            }
        }
        private void button17_Click(object sender, EventArgs e)
        {
            if (!lastIsOperation)
            {
                lastIsOperation = true;
                textBox1.Text = textBox1.Text + "+";
                textBox2.Text = "";
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            if (!lastIsOperation)
            {
                lastIsOperation = true;
                textBox1.Text = textBox1.Text + "-";
                textBox2.Text = "";
            }
        }

        private void evaluate()
        {
            string t = textBox1.Text;
            if (containOperation(t) && lastIsNumber())
            {
                while (containPower(t))
                {
                    int i = t.IndexOf('^');
                    t = doOperation(t, i, '^');
                }
                while (containTimes(t))
                {
                    int i = t.IndexOf('*');
                    t = doOperation(t, i, '*');
                }
                while (containDivide(t))
                {
                    int i = t.IndexOf('/');
                    t = doOperation(t, i, '/');
                }
                while (containAdd(t))
                {
                    int i = t.IndexOf('+');
                    t = doOperation(t, i, '+');
                }
                while (containSub(t))
                {
                    int i = t.IndexOf('-');
                    t = doOperation(t, i, '-');
                }
                textBox2.Text = t;
            }
        }

        private string doOperation(string t, int i, char op)
        {
            string newT = "";
            string num1 = "", num2 = "";
            int prevIndex = i - 1, postIndex = i + 1;
            while (Char.IsDigit(t[prevIndex]) || t[prevIndex] == '.')
            {
                num1 += t[prevIndex];
                if (prevIndex != 0)
                {
                    prevIndex--;
                }
                else
                {
                    break;
                }
            }
            if (prevIndex != 0)
            {
                prevIndex++;
            }
            num1 = rev(num1);

            while (Char.IsDigit(t[postIndex]) || t[prevIndex] == '.')
            {
                num2 += t[postIndex];
                if (postIndex != (t.Length - 1))
                {
                    postIndex++;
                }
                else
                {
                    break;
                }
            }
            if (postIndex != t.Length - 1)
            {
                postIndex--;
            }

            double n1 = double.Parse(num1);
            double n2 = double.Parse(num2);
            double r = 0;
            switch (op)
            {
                case '^':
                    r = Math.Pow(n1, n2);
                    break;
                case '*':
                    r = n1 * n2;
                    break;
                case '/':
                    r = n1 / n2;
                    break;
                case '+':
                    r = n1 + n2;
                    break;
                case '-':
                    r = n1 - n2;
                    break;
            }

            bool add = true;
            for (int j = 0; j < t.Length; j++)
            {
                if (j < prevIndex)
                {
                    newT += t[j];
                }
                else if (j > prevIndex && j < postIndex)
                {
                    if (add)
                    {
                        newT += r;
                        add = false;
                    }
                }
                else if (j > postIndex)
                {

                    newT += t[j];
                }
            }
            return newT;
        }

        private string rev(string s)
        {
            string temp = "";
            for (int i = s.Length - 1; i >= 0; i--)
            {
                temp += s[i];
            }
            return temp;
        }
        private bool containOperation(String t)
        {
            return (t.Contains('+') || t.Contains('-') || t.Contains('/') || t.Contains('*') || t.Contains('^'));
        }

        private bool containPower(String t)
        {
            return (t.Contains('^'));
        }
        private bool containTimes(String t)
        {
            return (t.Contains('*'));
        }

        private bool containDivide(String t)
        {
            return (t.Contains('/'));
        }
        private bool containAdd(String t)
        {
            return (t.Contains('+'));
        }
        private bool containSub(String t)
        {
            return (t.Contains('-'));
        }

        private bool lastIsNumber()
        {
            String t = textBox1.Text;
            if (t.Length == 0)
            {
                return false;
            }
            if (Char.IsDigit(t[t.Length - 1]))
            {
                return true;
            }
            return false;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length != 0)
            {
                textBox1.Text = textBox1.Text.Remove(textBox1.Text.Length - 1);
                if (lastIsNumber())
                {
                    evaluate();
                }
                else
                {
                    textBox2.Text = "";
                }
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
        }
    }
}
